import { GoogleGenAI, Type } from "@google/genai";
import { HouseFeatures, PredictionResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const predictHousePrice = async (features: HouseFeatures): Promise<PredictionResult> => {
  const model = "gemini-3-flash-preview";

  const prompt = `
    Act as an expert real estate appraiser and data scientist specialized in the Indian Real Estate Market (top Tier 1 and Tier 2 cities). 
    Predict the market value of a property in India (INR currency) with the following features:
    
    - Location Type: ${features.location} (Interpret this as: Downtown=City Center, Suburban=Residential Society, Urban=Metro Hub, Rural=Developing Outskirts)
    - Type: ${features.propertyType}
    - Super Built-up Area: ${features.squareFootage} sqft
    - Configuration: ${features.bedrooms} BHK, ${features.bathrooms} Bath
    - Plot Size: ${features.lotSize} acres (if applicable)
    - Year of Construction: ${features.yearBuilt}
    - Car Parking: ${features.garageSpaces}
    - Condition: ${features.condition}

    Provide a realistic price estimate in Indian Rupees (INR) based on current market trends in India.
    Also generate 5 realistic "comparable" sold properties (using realistic Indian addresses/localities) that would justify this price.
    Analyze the market trend based on current economic factors in India (RBI repo rates, infrastructure projects, etc.).
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          estimatedPrice: { type: Type.NUMBER, description: "The single point estimate price in INR" },
          priceRangeLow: { type: Type.NUMBER, description: "Lower bound of the estimate in INR" },
          priceRangeHigh: { type: Type.NUMBER, description: "Upper bound of the estimate in INR" },
          confidenceScore: { type: Type.NUMBER, description: "Confidence in prediction from 0 to 100" },
          reasoning: { type: Type.STRING, description: "A paragraph explaining the valuation factors specific to Indian market context" },
          marketTrend: { type: Type.STRING, enum: ["Up", "Down", "Stable"] },
          comparables: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                address: { type: Type.STRING, description: "Realistic Indian address (e.g., 'Prestige Shantiniketan, Whitefield, Bangalore')" },
                price: { type: Type.NUMBER, description: "Sold price in INR" },
                squareFootage: { type: Type.NUMBER },
                soldDate: { type: Type.STRING }
              }
            }
          }
        }
      }
    }
  });

  if (!response.text) {
    throw new Error("No response from AI");
  }

  return JSON.parse(response.text) as PredictionResult;
};