import React, { useState } from 'react';
import { HouseForm } from './components/HouseForm';
import { PredictionResult } from './components/PredictionResult';
import { EDASection } from './components/EDASection';
import { ModelTrainingSection } from './components/ModelTrainingSection';
import { HouseFeatures, PredictionResult as PredictionResultType, ModelType } from './types';
import { predictHousePrice } from './services/geminiService';
import { predictWithCustomModel } from './services/customModelService';
import { Building, Sparkles, Settings2, Network, Server, Menu, X, AlertCircle, Search, BarChart3, Calculator, Cpu } from 'lucide-react';

const App: React.FC = () => {
  const [result, setResult] = useState<PredictionResultType | null>(null);
  const [currentFeatures, setCurrentFeatures] = useState<HouseFeatures | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'predict' | 'eda' | 'training'>('predict');

  // Model Configuration State (Default to CUSTOM now since we have real data)
  const [modelType, setModelType] = useState<ModelType>('CUSTOM');
  const [customEndpoint, setCustomEndpoint] = useState<string>('simulation');

  const handlePrediction = async (features: HouseFeatures) => {
    setIsLoading(true);
    setError(null);
    setCurrentFeatures(features);
    // On mobile, close sidebar after submission to show results
    if (window.innerWidth < 1024) setIsSidebarOpen(false);
    
    // Auto switch to result view
    setViewMode('predict');
    
    try {
      let prediction: PredictionResultType;
      
      if (modelType === 'GEMINI') {
        prediction = await predictHousePrice(features);
      } else {
        prediction = await predictWithCustomModel(features, customEndpoint);
      }
      
      setResult(prediction);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to generate prediction. Please check your configuration.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen font-sans flex overflow-hidden dark-mesh-bg text-slate-200 selection:bg-fuchsia-500/30">
      
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/80 z-40 lg:hidden backdrop-blur-sm"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar / Navigation */}
      <div className={`
        fixed inset-y-0 left-0 w-[340px] bg-[#020617] transform transition-transform duration-300 ease-in-out z-50
        lg:translate-x-0 lg:static lg:block border-r border-slate-800
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        overflow-y-auto custom-scrollbar
      `}>
        <div className="p-8 relative min-h-full flex flex-col">
          {/* Brand */}
          <div className="relative z-10 flex items-center justify-between mb-10">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-indigo-600 to-purple-600 p-2 rounded-xl shadow-lg shadow-indigo-500/20">
                <Search className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight font-display text-white">Rental Finds</h1>
                <p className="text-[10px] text-indigo-400 font-bold tracking-widest uppercase">India Market</p>
              </div>
            </div>
            <button 
              onClick={() => setIsSidebarOpen(false)} 
              className="lg:hidden p-2 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex flex-col gap-2 mb-8">
            <button 
              onClick={() => setViewMode('predict')}
              className={`w-full px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-3 transition-all ${viewMode === 'predict' ? 'bg-slate-800 text-white shadow-lg border border-slate-700' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900/50'}`}
            >
              <Calculator className={`w-4 h-4 ${viewMode === 'predict' ? 'text-indigo-400' : ''}`} />
              Valuation Engine
            </button>
            <button 
              onClick={() => setViewMode('eda')}
              className={`w-full px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-3 transition-all ${viewMode === 'eda' ? 'bg-slate-800 text-white shadow-lg border border-slate-700' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900/50'}`}
            >
              <BarChart3 className={`w-4 h-4 ${viewMode === 'eda' ? 'text-emerald-400' : ''}`} />
              Market Insights
            </button>
            <button 
              onClick={() => setViewMode('training')}
              className={`w-full px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-3 transition-all ${viewMode === 'training' ? 'bg-slate-800 text-white shadow-lg border border-slate-700' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900/50'}`}
            >
              <Cpu className={`w-4 h-4 ${viewMode === 'training' ? 'text-fuchsia-400' : ''}`} />
              Model Training
            </button>
          </div>

          {/* Conditional Sidebar Content */}
          {viewMode === 'predict' && (
            <div className="animate-in fade-in slide-in-from-left-4 duration-300 flex flex-col gap-8 flex-1">
              {/* Model Toggle */}
              <div className="relative z-10">
                 <div className="flex items-center gap-2 mb-3 text-slate-400 pl-1">
                   <Settings2 className="w-3 h-3" />
                   <span className="text-[10px] font-bold uppercase tracking-widest">Prediction Engine</span>
                 </div>
                 
                 <div className="bg-slate-900 p-1 rounded-xl border border-slate-800">
                    <div className="grid grid-cols-2 gap-1">
                      <button 
                        onClick={() => setModelType('CUSTOM')}
                        className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-[10px] font-bold uppercase tracking-wide transition-all duration-200 ${modelType === 'CUSTOM' ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
                      >
                        <Server className="w-3 h-3" /> Historical
                      </button>
                      <button 
                        onClick={() => setModelType('GEMINI')}
                        className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-[10px] font-bold uppercase tracking-wide transition-all duration-200 ${modelType === 'GEMINI' ? 'bg-fuchsia-600/20 text-fuchsia-300 border border-fuchsia-500/30' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
                      >
                        <Sparkles className="w-3 h-3" /> Gemini AI
                      </button>
                    </div>
                 </div>
              </div>
              
              <div className="relative z-10">
                <HouseForm onSubmit={handlePrediction} isLoading={isLoading} />
              </div>
            </div>
          )}
          
          {viewMode === 'eda' && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-300 text-slate-400 text-sm leading-relaxed p-4 bg-slate-900/30 rounded-2xl border border-slate-800/50">
              <p className="mb-4 font-bold text-white">Indian Real Estate Data</p>
              <p className="mb-4">
                This dashboard analyzes property transactions across major Indian metros and developing tiers.
              </p>
              <p>
                Visualizations provide insights into price per sq.ft trends, BHK distribution, and premium vs affordable inventory mix.
              </p>
            </div>
          )}

          {viewMode === 'training' && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-300 text-slate-400 text-sm leading-relaxed p-4 bg-slate-900/30 rounded-2xl border border-slate-800/50">
              <p className="mb-4 font-bold text-white">Machine Learning Lab</p>
              <p className="mb-4">
                Execute live training cycles on the regression engine to optimize prediction accuracy.
              </p>
              <p>
                Evaluate performance using industry standard metrics: <span className="text-indigo-400">RMSE</span>, <span className="text-indigo-400">MAE</span>, and <span className="text-indigo-400">R-Squared</span>.
              </p>
            </div>
          )}

          <div className="mt-auto pt-8 border-t border-slate-800/50 text-center relative z-10">
             <p className="text-[10px] text-slate-600">
                &copy; 2024 Rental Finds India. <br/> Licensed for domestic use.
             </p>
          </div>
          
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        
        {/* Mobile Header */}
        <div className="lg:hidden p-4 flex items-center justify-between relative z-20 mx-4 mt-4 glass-panel rounded-xl">
           <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-indigo-400" />
            <h1 className="font-bold font-display text-white">Rental Finds</h1>
           </div>
           <button onClick={() => setIsSidebarOpen(true)} className="p-2 text-slate-400 hover:bg-slate-800 rounded-lg">
             <Menu className="w-6 h-6" />
           </button>
        </div>

        <main className="flex-1 overflow-y-auto p-4 lg:p-10 pb-20 scroll-smooth">
           <div className="max-w-6xl mx-auto">
             
             {/* Header Section */}
             <div className="mb-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  {viewMode === 'predict' && (
                    <>
                      <h2 className="text-3xl lg:text-4xl font-bold text-white font-display tracking-tight mb-2">
                        Property Valuation
                      </h2>
                      <p className="text-slate-400 font-medium max-w-lg leading-relaxed">
                        Accurate price discovery in <span className="text-indigo-400 font-bold">INR (₹)</span> powered by <span className="text-white font-bold">{modelType === 'GEMINI' ? 'Generative AI' : 'Market Dataset'}</span>.
                      </p>
                    </>
                  )}
                  {/* Titles for other sections handled internally */}
                </div>
                
                {viewMode === 'predict' && (
                  <div className="hidden sm:flex items-center gap-3">
                    <div className="px-4 py-2 bg-slate-900/50 backdrop-blur-md rounded-full border border-white/10 flex items-center gap-2 text-xs font-bold text-slate-300">
                      <div className={`w-2 h-2 rounded-full animate-pulse ${modelType === 'GEMINI' ? 'bg-fuchsia-500' : 'bg-indigo-500'}`}></div>
                      {modelType === 'GEMINI' ? 'AI Connected' : 'Dataset Active'}
                    </div>
                  </div>
                )}
             </div>

             {error && (
               <div className="bg-rose-950/30 border border-rose-500/30 p-4 mb-8 rounded-xl flex items-start gap-4 animate-in fade-in slide-in-from-top-4">
                  <div className="p-2 bg-rose-500/10 rounded-full text-rose-500 shrink-0">
                     <AlertCircle className="w-5 h-5" />
                   </div>
                   <div>
                     <h3 className="text-sm font-bold text-rose-200">Prediction Error</h3>
                     <p className="text-sm text-rose-300/80 mt-1">{error}</p>
                   </div>
               </div>
             )}

             {viewMode === 'predict' && (
                <PredictionResult result={result} features={currentFeatures} />
             )}
             
             {viewMode === 'eda' && (
                <EDASection />
             )}

             {viewMode === 'training' && (
                <ModelTrainingSection />
             )}
           </div>
        </main>
      </div>
    </div>
  );
};

export default App;