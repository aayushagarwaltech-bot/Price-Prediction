export interface HouseFeatures {
  squareFootage: number;
  bedrooms: number;
  bathrooms: number;
  lotSize: number; // in acres
  yearBuilt: number;
  location: string; // Zip code or Neighborhood name
  propertyType: PropertyType;
  garageSpaces: number;
  condition: PropertyCondition;
}

export enum PropertyType {
  SINGLE_FAMILY = 'Independent House / Villa',
  CONDO = 'Apartment / Flat',
  TOWNHOUSE = 'Builder Floor',
  MULTI_FAMILY = 'Farmhouse / Plot'
}

export enum PropertyCondition {
  POOR = 'Needs Renovation',
  FAIR = 'Average',
  GOOD = 'Ready to Move',
  EXCELLENT = 'Luxury / Premium'
}

export interface ComparableProperty {
  id: string;
  address: string;
  price: number;
  squareFootage: number;
  soldDate: string;
}

export interface PredictionResult {
  estimatedPrice: number;
  priceRangeLow: number;
  priceRangeHigh: number;
  confidenceScore: number; // 0-100
  reasoning: string;
  comparables: ComparableProperty[];
  marketTrend: 'Up' | 'Down' | 'Stable';
}

export interface TrainingMetrics {
  mae: number;
  rmse: number;
  r2: number;
  accuracy: number;
  trainingSize: number;
  testSize: number;
  residuals: { actual: number; predicted: number; error: number }[];
  featureImportance: { name: string; score: number }[];
  history: { epoch: number; loss: number }[]; // Simulated training curve
}

export type ModelType = 'GEMINI' | 'CUSTOM';