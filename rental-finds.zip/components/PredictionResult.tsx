import React from 'react';
import { PredictionResult as PredictionResultType, HouseFeatures } from '../types';
import { TrendingUp, TrendingDown, Minus, Info, Sparkles, ArrowRight, Activity, DollarSign } from 'lucide-react';
import { MarketChart } from './MarketChart';

interface PredictionResultProps {
  result: PredictionResultType | null;
  features: HouseFeatures | null;
}

export const PredictionResult: React.FC<PredictionResultProps> = ({ result, features }) => {
  if (!result || !features) {
    return (
      <div className="h-[600px] flex flex-col items-center justify-center text-slate-500 p-12 glass-panel rounded-3xl border-dashed border-2 border-slate-700/50">
        <div className="w-24 h-24 bg-slate-800/50 rounded-full flex items-center justify-center mb-6 shadow-inner border border-slate-700">
          <Sparkles className="w-10 h-10 text-slate-600" />
        </div>
        <h3 className="text-2xl font-bold text-white font-display tracking-tight">Awaiting Input</h3>
        <p className="mt-2 text-center max-w-sm leading-relaxed text-slate-400">
          Set your property parameters on the left to initialize the <span className="text-indigo-400 font-medium">Rental Finds</span> valuation engine.
        </p>
      </div>
    );
  }

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-700 ease-out">
      
      {/* Top Cards Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* HERO CARD: Price */}
        <div className="lg:col-span-2 relative overflow-hidden rounded-3xl shadow-2xl shadow-indigo-900/20 group">
          {/* Neon Glow Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950"></div>
          <div className="absolute bottom-0 right-0 w-64 h-64 bg-indigo-500/20 rounded-full blur-[80px]"></div>
          
          <div className="relative z-10 p-8 h-full flex flex-col justify-between text-white">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="text-xs font-bold tracking-[0.2em] text-indigo-200 uppercase">Fair Market Value</span>
                </div>
                <h2 className="text-4xl lg:text-6xl font-bold tracking-tighter font-display text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-indigo-200">
                  {formatCurrency(result.estimatedPrice)}
                </h2>
              </div>
              <div className="bg-white/5 backdrop-blur-md px-4 py-2 rounded-lg border border-white/10 text-xs font-bold font-mono tracking-wider shadow-lg text-indigo-300">
                {features.squareFootage} SQFT
              </div>
            </div>
            
            <div className="mt-10 pt-6 border-t border-white/5 flex flex-col sm:flex-row sm:items-center gap-8">
              <div>
                 <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider mb-2">Valuation Range</p>
                 <div className="flex items-center gap-3 font-display">
                   <p className="text-xl font-bold text-white">{formatCurrency(result.priceRangeLow)}</p>
                   <ArrowRight className="w-4 h-4 text-slate-500" />
                   <p className="text-xl font-bold text-white">{formatCurrency(result.priceRangeHigh)}</p>
                 </div>
              </div>
              
              <div className="sm:ml-auto flex items-center gap-4 bg-slate-950/30 rounded-2xl p-3 border border-white/5">
                <div className="text-right">
                   <p className="text-[10px] uppercase font-bold text-slate-400">Confidence</p>
                   <p className="text-xl font-bold text-emerald-400">{result.confidenceScore}%</p>
                </div>
                {/* Simple Donut Chart for Confidence */}
                <div className="w-10 h-10 rounded-full border-4 border-slate-800 border-t-emerald-400 rotate-45"></div>
              </div>
            </div>
          </div>
        </div>

        {/* INFO CARD: Trend & Stats */}
        <div className="glass-panel rounded-3xl p-6 flex flex-col gap-6 relative overflow-hidden">
           <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-cyan-500"></div>
           
           <div>
             <h3 className="text-slate-400 font-bold text-[10px] uppercase tracking-widest mb-4">Market Signal</h3>
             <div className="flex items-center gap-4">
                <div className={`p-3 rounded-xl border ${
                  result.marketTrend === 'Up' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 
                  result.marketTrend === 'Down' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' : 'bg-blue-500/10 border-blue-500/20 text-blue-400'
                }`}>
                   {result.marketTrend === 'Up' && <TrendingUp className="w-6 h-6" />}
                   {result.marketTrend === 'Down' && <TrendingDown className="w-6 h-6" />}
                   {result.marketTrend === 'Stable' && <Minus className="w-6 h-6" />}
                </div>
                <div>
                  <span className="text-2xl font-bold text-white font-display block">{result.marketTrend}</span>
                  <span className="text-xs text-slate-500 font-medium">Last 30 Days</span>
                </div>
             </div>
           </div>
           
           <div className="h-px bg-slate-800"></div>

           <div>
              <div className="flex items-center gap-2 mb-2">
                 <DollarSign className="w-4 h-4 text-cyan-400" />
                 <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Price / SqFt</span>
              </div>
              <div className="text-2xl font-bold text-white font-display">
                {formatCurrency(Math.round(result.estimatedPrice / (features?.squareFootage || 1)))}
              </div>
           </div>
        </div>
      </div>

      {/* Analysis Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Reasoning Text */}
        <div className="lg:col-span-1">
          <div className="glass-panel text-slate-300 p-8 rounded-3xl relative overflow-hidden h-full">
            <div className="flex items-center gap-2 mb-6 text-indigo-400 relative z-10">
              <Activity className="w-4 h-4" />
              <h4 className="font-bold uppercase tracking-widest text-[10px] text-white">Analysis Log</h4>
            </div>
            
            <div className="font-mono text-xs leading-relaxed opacity-90 relative z-10 text-slate-400">
              <p className="mb-4 text-emerald-400 font-bold">
                > TARGET_ACQUIRED: {features.location.toUpperCase()}
              </p>
              <p className="whitespace-pre-wrap">{result.reasoning}</p>
            </div>
          </div>
        </div>

        {/* Chart */}
        <div className="lg:col-span-2">
           <MarketChart 
            comparables={result.comparables} 
            predictedPrice={result.estimatedPrice} 
            subjectSquareFootage={features.squareFootage} 
          />
        </div>
      </div>
    </div>
  );
};