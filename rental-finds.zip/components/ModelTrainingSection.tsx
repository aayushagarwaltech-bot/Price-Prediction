import React, { useState } from 'react';
import { TrainingMetrics } from '../types';
import { runModelTraining } from '../services/customModelService';
import { Play, RotateCcw, CheckCircle2, Cpu, BarChart3, TrendingUp, Activity } from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  ScatterChart, Scatter, LineChart, Line 
} from 'recharts';

export const ModelTrainingSection: React.FC = () => {
  const [isTraining, setIsTraining] = useState(false);
  const [progress, setProgress] = useState(0);
  const [metrics, setMetrics] = useState<TrainingMetrics | null>(null);

  const startTraining = async () => {
    setIsTraining(true);
    setProgress(0);
    setMetrics(null);
    
    try {
      const results = await runModelTraining((p) => setProgress(p));
      setMetrics(results);
      setProgress(100);
    } catch (e) {
      console.error(e);
    } finally {
      setIsTraining(false);
    }
  };

  const formatINR = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumSignificantDigits: 3,
      notation: 'compact'
    }).format(val);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h2 className="text-3xl font-bold text-white font-display">Model Training Lab</h2>
        <p className="text-slate-400">Train the KNN regression engine on the dataset and evaluate performance metrics.</p>
      </div>

      {/* Control Panel */}
      <div className="glass-panel p-8 rounded-3xl border-2 border-indigo-500/20 relative overflow-hidden">
        {/* Animated Background Mesh */}
        <div className="absolute inset-0 bg-indigo-500/5 pointer-events-none"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h3 className="text-xl font-bold text-white font-display mb-2 flex items-center gap-2">
              <Cpu className="w-5 h-5 text-indigo-400" />
              Engine Configuration
            </h3>
            <p className="text-sm text-slate-400 max-w-md">
              Algorithm: <span className="text-indigo-300">Weighted K-Nearest Neighbors (k=5)</span><br/>
              Split Strategy: <span className="text-indigo-300">80% Train / 20% Test (Random Shuffle)</span>
            </p>
          </div>

          <div className="w-full md:w-auto">
            {!isTraining && !metrics && (
              <button 
                onClick={startTraining}
                className="w-full md:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/30 transition-all transform hover:scale-[1.02]"
              >
                <Play className="w-5 h-5 fill-current" />
                Initialize Training
              </button>
            )}

            {isTraining && (
              <div className="w-full md:w-64">
                <div className="flex justify-between text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                  <span>Training...</span>
                  <span>{progress}%</span>
                </div>
                <div className="h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 to-fuchsia-500 transition-all duration-100 ease-out"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
              </div>
            )}

            {metrics && !isTraining && (
              <button 
                onClick={startTraining}
                className="w-full md:w-auto px-8 py-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 border border-slate-600 transition-all"
              >
                <RotateCcw className="w-4 h-4" />
                Retrain Model
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Results View */}
      {metrics && (
        <div className="animate-in fade-in slide-in-from-bottom-8 duration-700 space-y-6">
          
          {/* Metrics Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="glass-panel p-5 rounded-2xl border-t-4 border-emerald-500">
              <div className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">Model Accuracy</div>
              <div className="text-3xl font-bold text-white font-display">{metrics.accuracy.toFixed(1)}%</div>
              <div className="text-emerald-400 text-xs mt-2 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Optimal Range
              </div>
            </div>
            <div className="glass-panel p-5 rounded-2xl border-t-4 border-indigo-500">
              <div className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">RMSE (Loss)</div>
              <div className="text-3xl font-bold text-white font-display">{formatINR(metrics.rmse)}</div>
              <div className="text-slate-500 text-xs mt-2">Root Mean Sq. Error</div>
            </div>
            <div className="glass-panel p-5 rounded-2xl border-t-4 border-fuchsia-500">
              <div className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">R² Score</div>
              <div className="text-3xl font-bold text-white font-display">{metrics.r2.toFixed(3)}</div>
              <div className="text-slate-500 text-xs mt-2">Goodness of Fit</div>
            </div>
            <div className="glass-panel p-5 rounded-2xl border-t-4 border-cyan-500">
              <div className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">Test Samples</div>
              <div className="text-3xl font-bold text-white font-display">{metrics.testSize}</div>
              <div className="text-slate-500 text-xs mt-2">Evaluated Records</div>
            </div>
          </div>

          {/* Charts Row 1 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Feature Importance */}
            <div className="glass-panel p-6 rounded-3xl">
              <h4 className="text-lg font-bold text-white font-display mb-6 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-400" /> Feature Importance
              </h4>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={metrics.featureImportance} layout="vertical" margin={{ left: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                    <XAxis type="number" hide />
                    <YAxis dataKey="name" type="category" width={100} tick={{fill: '#94a3b8', fontSize: 11}} axisLine={false} tickLine={false} />
                    <Tooltip 
                      cursor={{fill: '#1e293b'}}
                      contentStyle={{backgroundColor: '#0f172a', border: '1px solid #334155'}}
                    />
                    <Bar dataKey="score" fill="#6366f1" radius={[0, 4, 4, 0]} barSize={20} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Loss Curve */}
            <div className="glass-panel p-6 rounded-3xl">
              <h4 className="text-lg font-bold text-white font-display mb-6 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" /> Learning Curve (Loss)
              </h4>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={metrics.history}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis dataKey="epoch" tick={{fill: '#64748b'}} axisLine={{stroke: '#334155'}} tickLine={false} />
                    <YAxis tickFormatter={(val) => val.toFixed(0)} tick={{fill: '#64748b'}} axisLine={false} tickLine={false} />
                    <Tooltip 
                      contentStyle={{backgroundColor: '#0f172a', border: '1px solid #334155'}}
                      formatter={(val: number) => [val.toFixed(0), 'Loss']}
                    />
                    <Line type="monotone" dataKey="loss" stroke="#10b981" strokeWidth={3} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

          </div>

          {/* Residuals Plot */}
          <div className="glass-panel p-6 rounded-3xl">
            <h4 className="text-lg font-bold text-white font-display mb-2 flex items-center gap-2">
              <Activity className="w-5 h-5 text-fuchsia-400" /> Residual Analysis
            </h4>
            <p className="text-xs text-slate-400 mb-6">Predicted Price vs Actual Price (Ideal: Points close to diagonal)</p>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis 
                    type="number" 
                    dataKey="actual" 
                    name="Actual" 
                    unit=" INR" 
                    tickFormatter={formatINR}
                    tick={{fill: '#94a3b8'}} 
                    axisLine={{stroke: '#334155'}} 
                    tickLine={false} 
                  />
                  <YAxis 
                    type="number" 
                    dataKey="predicted" 
                    name="Predicted" 
                    unit=" INR" 
                    tickFormatter={formatINR}
                    tick={{fill: '#94a3b8'}} 
                    axisLine={false} 
                    tickLine={false} 
                  />
                  <Tooltip 
                    cursor={{ strokeDasharray: '3 3' }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-xl">
                            <p className="text-slate-400 text-xs mb-1">Error: {formatINR(d.error)}</p>
                            <div className="flex gap-4">
                              <div>
                                <span className="text-[10px] uppercase text-slate-500 font-bold">Actual</span>
                                <p className="text-white font-bold">{formatINR(d.actual)}</p>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase text-slate-500 font-bold">Predicted</span>
                                <p className="text-fuchsia-400 font-bold">{formatINR(d.predicted)}</p>
                              </div>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Scatter name="Residuals" data={metrics.residuals} fill="#d946ef" fillOpacity={0.6} shape="circle" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
