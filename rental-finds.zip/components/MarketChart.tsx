import React from 'react';
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Label,
  ZAxis
} from 'recharts';
import { ComparableProperty } from '../types';

interface MarketChartProps {
  comparables: ComparableProperty[];
  predictedPrice: number;
  subjectSquareFootage: number;
}

export const MarketChart: React.FC<MarketChartProps> = ({ comparables, predictedPrice, subjectSquareFootage }) => {
  const data = [
    ...comparables.map(c => ({ x: c.squareFootage, y: c.price, z: 100, name: 'Comparable', address: c.address })),
    { x: subjectSquareFootage, y: predictedPrice, z: 250, name: 'Subject Property', address: 'Estimated Value' }
  ];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumSignificantDigits: 3,
      notation: 'compact'
    }).format(value);
  };

  return (
    <div className="w-full h-[400px] glass-panel p-6 rounded-3xl relative">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-white font-display">Comparable Landscape</h3>
          <p className="text-xs text-slate-400">Scatter distribution of similar assets</p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
            <span className="text-slate-400">Dataset</span>
          </div>
           <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-fuchsia-500 shadow-[0_0_10px_rgba(217,70,239,0.5)]"></span>
            <span className="text-white font-bold">Subject</span>
          </div>
        </div>
      </div>
      
      <ResponsiveContainer width="100%" height={300}>
        <ScatterChart
          margin={{
            top: 20,
            right: 20,
            bottom: 20,
            left: 20,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
          <XAxis 
            type="number" 
            dataKey="x" 
            name="Size" 
            unit=" sqft" 
            domain={['auto', 'auto']}
            tick={{fontSize: 10, fill: '#64748b'}}
            tickLine={false}
            axisLine={{ stroke: '#334155' }}
          >
             <Label value="Square Footage" offset={-10} position="insideBottom" style={{fill: '#64748b', fontSize: 10}} />
          </XAxis>
          <YAxis 
            type="number" 
            dataKey="y" 
            name="Price" 
            tickFormatter={formatCurrency} 
            domain={['auto', 'auto']}
            tick={{fontSize: 10, fill: '#64748b'}}
            tickLine={false}
            axisLine={false}
          />
          <ZAxis type="number" dataKey="z" range={[50, 400]} />
          <Tooltip 
            cursor={{ strokeDasharray: '3 3', stroke: '#cbd5e1' }} 
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const data = payload[0].payload;
                const isSubject = data.name === 'Subject Property';
                return (
                  <div className={`p-3 shadow-2xl rounded-lg border backdrop-blur-md ${isSubject ? 'bg-fuchsia-950/90 border-fuchsia-500 text-white' : 'bg-slate-900/90 border-slate-700 text-slate-200'}`}>
                    <p className={`font-bold text-xs mb-1 ${isSubject ? 'text-fuchsia-300' : 'text-slate-400'}`}>{data.name}</p>
                    <p className="text-sm font-bold text-white mb-1">{data.address}</p>
                    <p className={`text-lg font-bold font-mono ${isSubject ? 'text-white' : 'text-indigo-400'}`}>{formatCurrency(data.y)}</p>
                    <div className="flex items-center gap-2 mt-1 opacity-60 text-[10px]">
                      <span>{data.x} sqft</span>
                    </div>
                  </div>
                );
              }
              return null;
            }}
          />
          
          {/* Comparables */}
          <Scatter 
            name="Comparables" 
            data={data.filter(d => d.name === 'Comparable')} 
            fill="#818cf8"
            fillOpacity={0.8}
            shape="circle" 
          />
          
          {/* Subject Property */}
          <Scatter 
            name="Subject" 
            data={data.filter(d => d.name === 'Subject Property')} 
            fill="#d946ef" 
            shape="circle"
          />
          
          <ReferenceLine 
            y={predictedPrice} 
            stroke="#d946ef" 
            strokeDasharray="3 3" 
            strokeOpacity={0.3} 
          />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
};