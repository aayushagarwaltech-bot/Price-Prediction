import React, { useState } from 'react';
import { HouseFeatures, PropertyType, PropertyCondition } from '../types';
import { Home, MapPin, Ruler, Bed, Bath, Car, Calendar, Activity, Zap, Layers, FileText } from 'lucide-react';

interface HouseFormProps {
  onSubmit: (features: HouseFeatures) => void;
  isLoading: boolean;
}

export const HouseForm: React.FC<HouseFormProps> = ({ onSubmit, isLoading }) => {
  const [features, setFeatures] = useState<HouseFeatures>({
    location: 'Suburban', // Default to match dataset key
    propertyType: PropertyType.CONDO,
    squareFootage: 1200,
    bedrooms: 2,
    bathrooms: 2,
    lotSize: 0.05,
    yearBuilt: 2015,
    garageSpaces: 1,
    condition: PropertyCondition.GOOD,
  });

  const handleChange = (field: keyof HouseFeatures, value: string | number) => {
    setFeatures(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(features);
  };

  // Dark Mode Styles
  const sectionTitleClass = "text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2";
  const inputGroupClass = "glass-panel rounded-2xl p-5 space-y-4 hover:border-indigo-500/30 transition-all duration-300";
  const labelClass = "block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1";
  const inputWrapperClass = "relative flex items-center group";
  const inputClass = "w-full pl-10 pr-4 py-2.5 bg-slate-900/50 border border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all text-sm text-white placeholder-slate-600 group-hover:bg-slate-900/80";
  const iconClass = "absolute left-3.5 w-4 h-4 text-slate-500 group-focus-within:text-indigo-400 transition-colors pointer-events-none";

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      
      {/* SECTION 1: CORE INFO */}
      <div>
        <h3 className={sectionTitleClass}>
          <MapPin className="w-3 h-3 text-fuchsia-400" /> Locality & Type
        </h3>
        <div className={inputGroupClass}>
          <div>
            <label className={labelClass}>Area Category</label>
            <div className={inputWrapperClass}>
              <MapPin className={iconClass} />
              <select
                value={features.location}
                onChange={(e) => handleChange('location', e.target.value)}
                className={`${inputClass} appearance-none cursor-pointer`}
              >
                <option value="Downtown">City Center / CBD</option>
                <option value="Suburban">Residential Society</option>
                <option value="Urban">Metro / High Street</option>
                <option value="Rural">Outskirts / Developing</option>
              </select>
            </div>
          </div>
          <div>
            <label className={labelClass}>Property Type</label>
            <div className={inputWrapperClass}>
              <Home className={iconClass} />
              <select
                value={features.propertyType}
                onChange={(e) => handleChange('propertyType', e.target.value)}
                className={`${inputClass} appearance-none cursor-pointer`}
              >
                {Object.values(PropertyType).map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 2: DIMENSIONS */}
      <div>
        <h3 className={sectionTitleClass}>
          <Layers className="w-3 h-3 text-cyan-400" /> Dimensions & Layout
        </h3>
        <div className={inputGroupClass}>
          <div className="grid grid-cols-2 gap-4">
             <div>
              <label className={labelClass}>Super Area (Sq. Ft)</label>
              <div className={inputWrapperClass}>
                <Ruler className={iconClass} />
                <input
                  type="number"
                  value={features.squareFootage}
                  onChange={(e) => handleChange('squareFootage', Number(e.target.value))}
                  className={inputClass}
                />
              </div>
            </div>
            <div>
              <label className={labelClass}>UDS / Plot (Acres)</label>
              <div className={inputWrapperClass}>
                <Layers className={iconClass} />
                <input
                  type="number"
                  step="0.01"
                  value={features.lotSize}
                  onChange={(e) => handleChange('lotSize', Number(e.target.value))}
                  className={inputClass}
                />
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Bedrooms (BHK)</label>
              <div className={inputWrapperClass}>
                <Bed className={iconClass} />
                <input
                  type="number"
                  value={features.bedrooms}
                  onChange={(e) => handleChange('bedrooms', Number(e.target.value))}
                  className={inputClass}
                />
              </div>
            </div>
            <div>
              <label className={labelClass}>Bathrooms</label>
              <div className={inputWrapperClass}>
                <Bath className={iconClass} />
                <input
                  type="number"
                  step="0.5"
                  value={features.bathrooms}
                  onChange={(e) => handleChange('bathrooms', Number(e.target.value))}
                  className={inputClass}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 3: FEATURES */}
      <div>
        <h3 className={sectionTitleClass}>
          <FileText className="w-3 h-3 text-indigo-400" /> Property Details
        </h3>
        <div className={inputGroupClass}>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Possession Year</label>
              <div className={inputWrapperClass}>
                <Calendar className={iconClass} />
                <input
                  type="number"
                  value={features.yearBuilt}
                  onChange={(e) => handleChange('yearBuilt', Number(e.target.value))}
                  className={inputClass}
                />
              </div>
            </div>
             <div>
              <label className={labelClass}>Car Parking</label>
              <div className={inputWrapperClass}>
                <Car className={iconClass} />
                <input
                  type="number"
                  value={features.garageSpaces}
                  onChange={(e) => handleChange('garageSpaces', Number(e.target.value))}
                  className={inputClass}
                />
              </div>
            </div>
          </div>
          <div>
            <label className={labelClass}>Furnishing Status</label>
             <div className={inputWrapperClass}>
              <Activity className={iconClass} />
              <select
                  value={features.condition}
                  onChange={(e) => handleChange('condition', e.target.value)}
                  className={`${inputClass} appearance-none cursor-pointer`}
                >
                  {Object.values(PropertyCondition).map(t => <option key={t} value={t}>{t}</option>)}
                </select>
            </div>
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className={`w-full py-4 px-4 rounded-xl font-bold text-white transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg flex items-center justify-center gap-2 group relative overflow-hidden ${
          isLoading
            ? 'bg-slate-800 cursor-not-allowed text-slate-400'
            : 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-500/25 border border-white/10'
        }`}
      >
        {!isLoading && <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>}
        
        {isLoading ? (
          <>
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            <span>Calculating Valuation...</span>
          </>
        ) : (
          <>
            <Zap className="w-5 h-5 fill-white group-hover:fill-yellow-300 transition-colors" />
            <span className="tracking-wide">ESTIMATE PRICE</span>
          </>
        )}
      </button>
    </form>
  );
};