import React, { useMemo } from 'react';
import { getRealEstateData, RealEstateRecord } from '../data/realEstateData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ScatterChart, Scatter, Label, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Home, Map, DollarSign } from 'lucide-react';

export const EDASection: React.FC = () => {
  const data = useMemo(() => getRealEstateData(), []);

  // --- STATISTICS CALCULATIONS ---
  const totalProperties = data.length;
  const avgPrice = data.reduce((sum, item) => sum + item.Price, 0) / totalProperties;
  const avgArea = data.reduce((sum, item) => sum + item.Area, 0) / totalProperties;
  
  // Format INR Currency
  const formatINR = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumSignificantDigits: 3,
      notation: 'compact'
    }).format(val);
  };

  // --- CHART DATA PREPARATION ---

  // 1. Average Price by Location
  const locationStats = useMemo(() => {
    const groups: Record<string, { total: number, count: number }> = {};
    data.forEach(d => {
      if (!groups[d.Location]) groups[d.Location] = { total: 0, count: 0 };
      groups[d.Location].total += d.Price;
      groups[d.Location].count += 1;
    });
    return Object.keys(groups).map(loc => ({
      name: loc,
      avgPrice: Math.round(groups[loc].total / groups[loc].count)
    })).sort((a, b) => b.avgPrice - a.avgPrice);
  }, [data]);

  // 2. Condition Distribution
  const conditionStats = useMemo(() => {
    const groups: Record<string, number> = {};
    data.forEach(d => {
      groups[d.Condition] = (groups[d.Condition] || 0) + 1;
    });
    return Object.keys(groups).map(cond => ({ name: cond, value: groups[cond] }));
  }, [data]);

  // 3. Price vs Area (Sampled for performance)
  const scatterData = useMemo(() => data.slice(0, 150).map(d => ({ x: d.Area, y: d.Price, loc: d.Location })), [data]);

  const COLORS = ['#6366f1', '#ec4899', '#06b6d4', '#8b5cf6'];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h2 className="text-3xl font-bold text-white font-display">Market Insights</h2>
        <p className="text-slate-400">Deep dive into the 1,000+ property dataset powering our AI.</p>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-panel p-4 rounded-2xl flex flex-col justify-between h-28">
           <div className="flex items-center gap-2 text-indigo-400">
             <Home className="w-4 h-4" />
             <span className="text-xs font-bold uppercase tracking-wider">Properties</span>
           </div>
           <p className="text-3xl font-bold text-white font-display">{totalProperties}</p>
        </div>
        <div className="glass-panel p-4 rounded-2xl flex flex-col justify-between h-28">
           <div className="flex items-center gap-2 text-emerald-400">
             <DollarSign className="w-4 h-4" />
             <span className="text-xs font-bold uppercase tracking-wider">Avg. Price</span>
           </div>
           <p className="text-3xl font-bold text-white font-display">{formatINR(avgPrice)}</p>
        </div>
        <div className="glass-panel p-4 rounded-2xl flex flex-col justify-between h-28">
           <div className="flex items-center gap-2 text-cyan-400">
             <Map className="w-4 h-4" />
             <span className="text-xs font-bold uppercase tracking-wider">Locations</span>
           </div>
           <p className="text-3xl font-bold text-white font-display">{locationStats.length}</p>
        </div>
        <div className="glass-panel p-4 rounded-2xl flex flex-col justify-between h-28">
           <div className="flex items-center gap-2 text-fuchsia-400">
             <TrendingUp className="w-4 h-4" />
             <span className="text-xs font-bold uppercase tracking-wider">Avg. Size</span>
           </div>
           <p className="text-3xl font-bold text-white font-display">{Math.round(avgArea)} <span className="text-sm font-normal text-slate-500">sqft</span></p>
        </div>
      </div>

      {/* Main Charts Area */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Price by Location Bar Chart */}
        <div className="glass-panel p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-white font-display mb-6">Average Price by Location</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={locationStats}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" tick={{fill: '#94a3b8', fontSize: 12}} axisLine={false} tickLine={false} />
                <YAxis tickFormatter={formatINR} tick={{fill: '#94a3b8', fontSize: 10}} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{fill: '#1e293b'}}
                  contentStyle={{backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '8px'}}
                  itemStyle={{color: '#fff'}}
                  formatter={(value: number) => formatINR(value)}
                />
                <Bar dataKey="avgPrice" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Condition Pie Chart */}
        <div className="glass-panel p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-white font-display mb-6">Market Inventory by Condition</h3>
          <div className="h-[300px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={conditionStats}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {conditionStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="rgba(0,0,0,0)" />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '8px'}}
                   itemStyle={{color: '#fff'}}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 mt-2">
            {conditionStats.map((entry, index) => (
              <div key={entry.name} className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full" style={{backgroundColor: COLORS[index % COLORS.length]}}></span>
                <span className="text-xs text-slate-400">{entry.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Price vs Area Scatter */}
        <div className="lg:col-span-2 glass-panel p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-white font-display mb-2">Price Correlation Matrix</h3>
          <p className="text-xs text-slate-400 mb-6">Analyzing the relationship between square footage and market price (Sample of 150 properties)</p>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis type="number" dataKey="x" name="Area" unit=" sqft" tick={{fill: '#94a3b8'}} axisLine={{stroke: '#334155'}} tickLine={false} />
                <YAxis type="number" dataKey="y" name="Price" tickFormatter={formatINR} tick={{fill: '#94a3b8'}} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ strokeDasharray: '3 3' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload;
                      return (
                        <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-xl">
                          <p className="text-indigo-400 font-bold text-xs mb-1">{d.loc}</p>
                          <p className="text-white font-bold">{formatINR(d.y)}</p>
                          <p className="text-slate-400 text-xs">{d.x} sqft</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Scatter name="Properties" data={scatterData} fill="#ec4899" fillOpacity={0.6} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
};
