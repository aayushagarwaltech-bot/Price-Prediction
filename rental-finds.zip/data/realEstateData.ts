// Embedding a subset of the provided CSV data for client-side processing.
// In a production app, this would be fetched from a database.

const csvData = `Id,Area,Bedrooms,Bathrooms,Floors,YearBuilt,Location,Condition,Garage,Price
1,1360,5,4,3,1970,Downtown,Excellent,No,149919
2,4272,5,4,3,1958,Downtown,Excellent,No,424998
3,3592,2,2,3,1938,Downtown,Good,No,266746
4,966,4,2,2,1902,Suburban,Fair,Yes,244020
5,4926,1,4,2,1975,Downtown,Fair,Yes,636056
6,3944,1,2,1,1906,Urban,Poor,No,93262
7,3671,1,1,2,1948,Rural,Poor,Yes,448722
8,3419,2,4,1,1925,Suburban,Good,Yes,594893
9,630,2,2,1,1932,Rural,Poor,Yes,652878
10,2185,3,3,1,2000,Downtown,Poor,No,340375
11,1269,1,4,2,1947,Suburban,Poor,Yes,653685
12,2891,4,4,3,1978,Urban,Excellent,Yes,127123
13,2933,4,3,2,1901,Downtown,Poor,No,849947
14,1684,1,1,1,2004,Rural,Good,No,399355
15,3885,1,3,1,1970,Urban,Fair,Yes,481838
16,4617,1,4,2,1931,Downtown,Poor,No,853032
17,3404,2,1,1,1903,Urban,Fair,Yes,208964
18,974,2,2,1,1919,Downtown,Poor,Yes,905742
19,1582,2,2,2,2013,Suburban,Good,No,989305
20,3058,5,2,2,2016,Downtown,Excellent,No,218767
21,2547,4,4,2,1935,Suburban,Good,Yes,996357
22,3247,4,3,1,1931,Downtown,Excellent,No,709789
23,1475,3,1,1,1927,Downtown,Poor,No,709966
24,2306,2,2,3,1976,Rural,Poor,Yes,447694
25,689,5,1,3,1900,Urban,Excellent,Yes,688668
26,3234,5,4,2,1959,Urban,Good,Yes,527032
27,3505,4,2,3,1955,Urban,Good,Yes,745494
28,2399,2,4,1,1934,Downtown,Excellent,Yes,513179
29,1767,3,3,3,2011,Downtown,Poor,Yes,948212
30,2028,2,4,1,1929,Downtown,Excellent,No,206547
31,3702,1,4,2,1953,Suburban,Poor,No,902609
32,4056,2,3,2,1935,Suburban,Excellent,Yes,727090
33,4390,1,1,1,2020,Rural,Poor,No,202185
34,1146,1,3,3,1954,Downtown,Excellent,No,725371
35,3388,3,3,2,1988,Urban,Fair,Yes,105746
36,2935,4,4,2,1979,Urban,Poor,No,959507
37,1100,2,1,3,1957,Rural,Good,No,748213
38,2863,1,2,3,1982,Urban,Excellent,Yes,921627
39,2561,2,3,1,1964,Rural,Good,No,873250
40,741,4,1,3,1968,Downtown,Excellent,No,218393
41,2541,4,3,3,1950,Urban,Good,Yes,333453
42,3324,5,3,3,1921,Downtown,Good,No,986192
43,3112,4,3,1,1987,Suburban,Excellent,No,340320
44,1863,3,3,1,2006,Urban,Excellent,No,643167
45,1978,1,4,2,2008,Suburban,Good,Yes,641880
46,3056,5,1,1,2015,Urban,Good,Yes,396872
47,1275,3,1,2,2000,Downtown,Good,No,270084
48,4514,2,1,3,1952,Rural,Poor,No,976920
49,534,1,3,2,1999,Downtown,Poor,Yes,771782
50,3652,4,4,2,1935,Downtown,Fair,Yes,845016
51,2455,1,3,3,1967,Downtown,Poor,No,698843
52,2085,2,3,2,1935,Urban,Poor,Yes,405446
53,4443,5,1,1,1951,Rural,Excellent,No,958840
54,3573,5,3,1,1952,Suburban,Fair,No,593118
55,1521,5,2,1,1981,Downtown,Fair,Yes,266897
56,3961,4,3,1,1949,Urban,Poor,Yes,826522
57,3113,3,2,2,1979,Suburban,Excellent,No,913498
58,4343,3,3,2,1940,Downtown,Excellent,No,840023
59,2000,1,4,3,1917,Suburban,Fair,Yes,143878
60,661,4,4,2,1921,Downtown,Excellent,No,175407
61,4797,5,1,2,1965,Suburban,Good,Yes,691157
62,2481,5,3,2,1920,Suburban,Poor,Yes,307716
63,1495,2,2,3,1999,Rural,Good,Yes,857827
64,3842,2,2,1,1943,Rural,Fair,Yes,66738
65,4298,5,3,2,2002,Downtown,Fair,Yes,183703
66,1775,5,2,3,1946,Urban,Excellent,No,723265
67,1516,4,4,3,1938,Rural,Excellent,Yes,593344
68,837,3,2,3,1928,Suburban,Fair,Yes,815034
69,1378,2,1,1,1953,Rural,Fair,Yes,560241
70,1576,3,4,2,1989,Rural,Good,Yes,433800
71,4493,4,4,3,1984,Downtown,Good,Yes,689604
72,879,5,4,1,1916,Rural,Excellent,Yes,740807
73,992,3,3,3,1979,Rural,Good,Yes,628706
74,2562,5,3,3,1959,Suburban,Excellent,No,873622
75,4384,5,4,3,1930,Rural,Excellent,No,76014
76,564,1,3,3,2014,Suburban,Poor,No,778359
77,3068,3,2,3,1972,Rural,Excellent,No,813277
78,2527,3,3,1,1994,Rural,Good,Yes,231350
79,3195,5,3,2,1977,Urban,Fair,No,961995
80,1995,4,4,2,1948,Rural,Fair,Yes,838212
81,891,1,1,2,2000,Suburban,Good,No,534859
82,4974,5,1,2,1901,Suburban,Fair,No,764618
83,4061,2,1,1,2015,Downtown,Excellent,Yes,540339
84,2778,2,2,1,1947,Downtown,Fair,Yes,92192
85,3599,1,3,1,2009,Urban,Good,No,941307
86,700,4,1,3,1913,Suburban,Fair,No,411273
87,3604,5,4,3,1958,Suburban,Excellent,No,93923
88,2954,3,1,3,1996,Suburban,Excellent,No,663484
89,4145,1,1,2,1998,Urban,Good,Yes,576683
90,1304,4,3,3,1957,Suburban,Good,No,414593
91,3231,3,3,2,2002,Downtown,Good,No,433891
92,3273,2,3,3,1957,Urban,Poor,No,802744
93,2070,2,2,2,2010,Downtown,Poor,No,458995
94,3190,3,2,3,1950,Downtown,Excellent,No,645316
95,4340,1,1,3,1983,Urban,Poor,Yes,997226
96,1528,2,3,1,1901,Rural,Poor,Yes,450327
97,1002,5,1,3,2014,Rural,Fair,Yes,816751
98,4993,3,4,3,1940,Downtown,Poor,Yes,715344
99,1370,3,4,1,1982,Rural,Fair,Yes,929608
100,4988,2,3,2,2022,Suburban,Good,No,777688
101,706,1,3,1,2000,Urban,Fair,Yes,305315
102,1984,5,4,1,1981,Downtown,Fair,Yes,339068
103,1363,1,3,2,1915,Suburban,Good,No,495919
104,3290,4,2,3,1903,Rural,Good,Yes,344721
105,1063,4,2,2,1911,Suburban,Excellent,Yes,188783
106,4691,2,3,3,1928,Rural,Excellent,Yes,659836
107,2257,2,4,3,1906,Downtown,Excellent,Yes,307288
108,2178,2,1,2,1913,Suburban,Excellent,No,543085
109,3742,4,3,1,2018,Urban,Fair,No,545187
110,1559,1,3,2,1911,Downtown,Fair,Yes,699381
111,2222,1,1,3,1998,Suburban,Excellent,No,285835
112,3814,2,3,2,1904,Suburban,Poor,Yes,971600
113,3657,5,1,2,1980,Rural,Excellent,No,902987
114,3125,1,4,3,2021,Downtown,Poor,No,401992
115,3229,4,2,1,2005,Downtown,Good,No,256084
116,2097,3,4,2,1931,Downtown,Fair,No,844686
117,3560,3,2,3,1973,Downtown,Fair,No,437554
118,3193,3,1,3,1942,Rural,Poor,No,803315
119,4127,5,2,2,1980,Urban,Excellent,No,520336
120,1863,2,4,1,1968,Downtown,Fair,No,973469
121,2481,4,2,2,1944,Rural,Poor,No,258072
122,2163,5,1,1,2005,Urban,Good,No,298029
123,2029,4,2,1,1908,Urban,Good,No,259047
124,2538,4,3,1,1948,Rural,Fair,Yes,415169
125,3802,2,4,1,1932,Downtown,Excellent,No,180509
126,2737,3,3,2,1999,Urban,Poor,Yes,812072
127,1806,2,1,3,1999,Downtown,Fair,No,345107
128,4529,5,2,3,1917,Downtown,Good,Yes,577561
129,3175,5,3,3,1908,Suburban,Excellent,Yes,589618
130,1782,5,3,3,1961,Downtown,Poor,Yes,202566
131,1209,2,2,3,1956,Suburban,Fair,No,650710
132,4913,4,2,3,1928,Urban,Poor,No,958521
133,4248,4,4,2,2013,Rural,Excellent,No,53212
134,1163,1,3,1,1977,Suburban,Excellent,No,282131
135,2498,5,3,3,1924,Rural,Good,Yes,526657
136,3945,4,1,2,1914,Urban,Excellent,No,661882
137,4243,1,4,3,1905,Downtown,Fair,No,182152
138,1995,4,1,3,2019,Urban,Poor,No,344819
139,3804,5,3,1,1941,Rural,Excellent,No,72007
140,4263,3,1,1,1928,Urban,Excellent,No,688093
141,2353,5,3,1,1978,Downtown,Fair,No,394785
142,1791,2,3,3,1992,Urban,Poor,No,670103
143,4081,4,1,3,1903,Downtown,Poor,No,883247
144,3957,4,1,3,1981,Suburban,Good,Yes,919914
145,2136,2,2,1,2013,Rural,Good,Yes,837071
146,4196,2,2,2,1956,Downtown,Poor,No,375737
147,3499,3,2,3,1948,Downtown,Fair,No,562164
148,3652,4,3,3,1943,Urban,Fair,No,128038
149,1198,4,1,3,2002,Suburban,Good,No,406043
150,2660,3,4,2,1979,Downtown,Excellent,Yes,840168
151,4597,1,3,3,1974,Suburban,Fair,Yes,827794
152,1354,3,4,2,1913,Suburban,Excellent,No,66473
153,3974,5,1,3,1902,Urban,Fair,Yes,703059
154,2207,4,3,2,2014,Downtown,Poor,Yes,175801
155,3277,2,4,3,2013,Urban,Good,No,944030
156,2233,5,4,1,1961,Rural,Excellent,No,660911
157,4010,4,2,1,2005,Rural,Excellent,No,558252
158,702,3,2,1,1963,Downtown,Poor,Yes,275097
159,3755,5,2,1,2001,Suburban,Fair,Yes,348964
160,4718,4,3,3,1944,Downtown,Excellent,No,265933
161,4996,1,1,1,2005,Downtown,Fair,No,369733
162,1266,1,1,2,1981,Rural,Poor,Yes,771167
163,4889,2,2,1,1957,Rural,Good,Yes,330558
164,2827,4,2,1,1919,Suburban,Excellent,No,439522
165,3431,1,2,1,1957,Suburban,Fair,Yes,74220
166,697,3,4,3,2011,Downtown,Excellent,No,634819
167,2430,4,2,1,1988,Urban,Fair,No,422146
168,4082,3,4,2,1956,Downtown,Fair,Yes,557409
169,1108,3,1,1,2001,Suburban,Fair,Yes,747785
170,3772,1,3,1,1976,Urban,Poor,Yes,59387
171,1647,4,3,1,1967,Rural,Good,No,295752
172,4782,5,3,2,2018,Suburban,Excellent,No,651103
173,3897,1,3,1,1977,Suburban,Good,No,601872
174,3011,1,4,2,1996,Urban,Fair,No,619071
175,2294,4,4,2,1991,Suburban,Fair,No,745169
176,1159,4,2,1,1951,Suburban,Good,No,759687
177,3311,3,4,2,1936,Suburban,Good,Yes,698782
178,1869,4,2,3,1907,Suburban,Excellent,No,690102
179,2486,3,2,1,1943,Suburban,Fair,No,300139
180,646,1,3,1,1997,Suburban,Good,No,967184
181,3719,2,4,2,2007,Suburban,Poor,No,550228
182,3411,5,4,2,1904,Suburban,Fair,Yes,716217
183,2234,1,2,1,2017,Rural,Fair,No,747621
184,2343,4,2,3,1968,Suburban,Excellent,Yes,910020
185,988,5,1,2,1930,Rural,Poor,Yes,984499
186,3476,2,1,2,1944,Rural,Excellent,No,296509
187,2459,2,2,3,1908,Downtown,Poor,No,63580
188,2885,3,1,3,2005,Downtown,Excellent,Yes,592528
189,3419,5,1,1,1931,Rural,Poor,Yes,828639
190,2302,3,2,3,1932,Rural,Poor,No,395590
191,4561,1,2,1,1966,Suburban,Poor,Yes,518968
192,3869,5,4,3,1929,Downtown,Good,No,940965
193,762,1,2,2,2013,Urban,Fair,No,828559
194,1123,3,2,1,1975,Downtown,Poor,Yes,533663
195,1516,5,3,1,1928,Rural,Good,No,478082
196,4143,3,4,1,1902,Rural,Good,No,655262
197,2549,5,4,3,1989,Suburban,Excellent,No,647689
198,4223,3,4,2,1956,Suburban,Fair,Yes,263165
199,3608,2,3,1,1929,Downtown,Fair,Yes,455427
200,4590,3,2,1,1908,Suburban,Excellent,Yes,502201`;

export interface RealEstateRecord {
  Id: number;
  Area: number;
  Bedrooms: number;
  Bathrooms: number;
  Floors: number;
  YearBuilt: number;
  Location: string;
  Condition: string;
  Garage: string;
  Price: number;
}

// Exchange rate approx USD to INR for realistic Indian Property Prices
const EXCHANGE_RATE = 83;

export const getRealEstateData = (): RealEstateRecord[] => {
  const lines = csvData.trim().split('\n');
  const headers = lines[0].split(',');
  
  return lines.slice(1).map(line => {
    const values = line.split(',');
    return {
      Id: Number(values[0]),
      Area: Number(values[1]),
      Bedrooms: Number(values[2]),
      Bathrooms: Number(values[3]),
      Floors: Number(values[4]),
      YearBuilt: Number(values[5]),
      Location: values[6],
      Condition: values[7],
      Garage: values[8],
      Price: Number(values[9]) * EXCHANGE_RATE // Convert raw USD-like value to INR
    };
  });
};
